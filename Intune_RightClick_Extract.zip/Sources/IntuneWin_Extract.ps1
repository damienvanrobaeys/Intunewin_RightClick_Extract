#========================================================================
#
# Author 	: systanddeploy (Damien VAN ROBAEYS)
# Website	: http://www.systanddeploy.com/
#
#========================================================================

Param
 (
	[String]$ScriptPath	
 )

# Extract intunewin content
$RightClick_Path = "$env:PROGRAMDATA\IntuneWin_Extract"
set-location $RightClick_Path
& .\IntuneWinAppUtilDecoder.exe $ScriptPath -s	

# Get path of the decoded file after intunewin extraction
$Intunewin_Extract_Directory = (get-item $ScriptPath).Directory	
$IntuneWin_File_Name = (get-item $ScriptPath).BaseName		
$IntuneWinDecoded_File = "$Intunewin_Extract_Directory\$IntuneWin_File_Name.decoded.zip"	

# Get full path where files will be extracted from the intunewin decoded ZIP file
$Extract_Folder = (get-item $ScriptPath).BaseName
$Extract_DirectoryName = (get-item $ScriptPath).DirectoryName
$Full_Extract_Path = "$Extract_DirectoryName\$Extract_Folder"

# Extract content from the ZIP
Expand-Archive -LiteralPath $IntuneWinDecoded_File -DestinationPath $Full_Extract_Path -Force

# Remove the decoded file
Remove-Item $IntuneWinDecoded_File

# Open extracted intunewin sources in explorer
Invoke-item $Full_Extract_Path

[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[System.Windows.Forms.MessageBox]::Show("Your intunewin package has been correctly exported")