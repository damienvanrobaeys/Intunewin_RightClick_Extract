#***************************************************************************************************************
# Author: Damien VAN ROBAEYS
# Website: http://www.systanddeploy.com
# Twitter: https://twitter.com/syst_and_deploy
#***************************************************************************************************************
[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

$Current_Folder = split-path $MyInvocation.MyCommand.Path
$Sources = $Current_Folder + "\" + "Sources\*"
If(test-path $Sources)
	{	
		$IntuneWin_Extract_Folder = "$env:LOCALAPPDATA\IntuneWin_Extract"
		try{
			new-item $IntuneWin_Extract_Folder -Force -ItemType directory
		}
		catch{
			EXIT
		}
				
		try{
			copy-item $Sources $IntuneWin_Extract_Folder -force -recurse
		}
		catch{
			EXIT
		}		

		$Intunewin_Shell_Registry_Key = "HKCU:\SOFTWARE\Classes\SystemFileAssociations\.intunewin"
		If(test-path $Intunewin_Shell_Registry_Key){remove-item $Intunewin_Shell_Registry_Key -recurse -force}

		New-Item $Intunewin_Shell_Registry_Key -Force

		$Intunewin_Key_Label = "Extract intunewin file"
		$Intunewin_Key_Label_Path = "$Intunewin_Shell_Registry_Key\Shell\$Intunewin_Key_Label"
		New-Item $Intunewin_Key_Label_Path -Force

		$Intunewin_Command_Path = "$Intunewin_Key_Label_Path\Command"

		$Command = "`"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe`" -sta -windowstyle hidden -file `"$IntuneWin_Extract_Folder\IntuneWin_Extract.ps1`" -NoExit -Command Set-Location -LiteralPath `"%V`" -ScriptPath `"%V`""

		new-item $Intunewin_Command_Path | out-null	
		Set-Item -Path $Intunewin_Command_Path -Value $Command -force | out-null	
		$Icon_Path = "$IntuneWin_Extract_Folder\logo.ico"
		New-ItemProperty -Path $Intunewin_Key_Label_Path -Name "Icon" -PropertyType String -Value $Icon_Path | out-null			
		[System.Windows.Forms.MessageBox]::Show("Intunewin context menu has been added")			
	}
Else
	{
		[System.Windows.Forms.MessageBox]::Show("It seems you don't have dowloaded all the folder structure.`nThe folder Sources is missing !!!")	
	}
